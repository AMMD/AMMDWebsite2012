<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-videos?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// V
	'videos_description' => 'This plugin allows the integration, using a simple copy/paste of URL, of videos hosted on major platforms (Dailymotion, Vimeo, YouTube, Culturebox) and manage them as spip documents. It also allows the HTML5 display of video in MP4, H.264, Ogg, WebM anf Mkv formats, even in mobile browsers.',
	'videos_nom' => 'Video(s)',
	'videos_slogan' => 'Management interface and integration models of videos'
);

?>
