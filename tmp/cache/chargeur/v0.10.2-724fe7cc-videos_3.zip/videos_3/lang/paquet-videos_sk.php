<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-videos?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// V
	'videos_description' => 'Tento zásuvný modul vám umožňuje vkladať z jednoduchej kópie/prilepenia internetových adries videí zo všetkých významných sietí (Dailymotion, Vimeo, Youtube, CultureBox)
			a ovládať ich ako objekty SPIPu. Umožňuje zobraziť aj HTML5 pre videá  formátov MP4, H264, Ogg,
			WebM a Mkv, a dokonca aj v prehliadačoch mobilných telefónov.',
	'videos_nom' => 'Videá',
	'videos_slogan' => 'Rozhranie na riadenie videí a šablóny na ich vkladanie'
);

?>
